﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RestaurantReviewTest
{
    [TestClass]
    public class RestaurantReviewTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
